<?php
	require_once( "../db.inc.php" );
	require_once( "../facilities.inc.php" );

	echo buildNavTreeHTML();
	exit;
?>
