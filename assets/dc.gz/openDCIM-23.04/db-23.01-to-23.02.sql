---
--- No actual db schema changes in this version, only a version bump
---

UPDATE fac_Config set Value="23.02" WHERE Parameter="Version";
