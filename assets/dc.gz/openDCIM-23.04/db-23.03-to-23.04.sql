---
--- Schema changes for 23.03 to 23.04
---

UPDATE fac_Config set Value="23.04" WHERE Parameter="Version";
