--
-- Bump up the database version (uncomment below once released)
--

UPDATE fac_Config set Value="21.01" WHERE Parameter="Version";
