<?php
	define( "VERSION", "23.04" );
?>
