<!doctype html>
<html>
<head>
<title>Unauthorized</title>
</head>
<body>
<h1>UserID not found in the database for authorized access.  Please contact your site administrator if this is in error.</h1>
</body>
</html>
