<?php
	include 'db.inc.php';
	include 'facilities.inc.php';

	LogActions::Prune(90);
?>
